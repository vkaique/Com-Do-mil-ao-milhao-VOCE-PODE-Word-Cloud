# 📘 Word Cloud - Book 📚
![24](https://user-images.githubusercontent.com/76967004/113323463-5b803c80-92ec-11eb-9dc5-9ce3650caaaa.jpg)
